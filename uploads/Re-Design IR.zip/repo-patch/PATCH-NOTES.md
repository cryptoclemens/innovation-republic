# SEO-Pass — Patch übernehmen

Ordner `repo-patch/` enthält den vollständigen SEO-Pass für `cryptoclemens/innovation-republic`.

## Inhalt

```
repo-patch/
├── index.html                  → Repo-Root (Dev-Entry mit vollem SEO-Head)
├── _app.jsx                    → Repo-Root (Hash-Router, ProductionApp, DevApp getrennt)
├── build.mjs                   → Repo-Root (Production-Build ohne Canvas, mit SEO-Files)
├── robots.txt                  → Repo-Root (statisch, ergänzend zum Build)
├── sitemap.xml                 → Repo-Root (statisch, ergänzend zum Build)
├── SEO-CHECKLIST.md            → Repo-Root (Status nach Patch)
├── assets/
│   └── og-image.png            → assets/og-image.png (1200×630)
└── directionA/
    ├── legal.jsx               → directionA/legal.jsx (NEU — Impressum + Datenschutz)
    └── shared.jsx              → directionA/shared.jsx (Hash-Routes statt href="#")
```

## Anwenden

In Claude Code (oder per Hand) ins Repo kopieren:

```bash
# Im Repo-Root
cp <thisproj>/repo-patch/index.html .
cp <thisproj>/repo-patch/_app.jsx .
cp <thisproj>/repo-patch/build.mjs .
cp <thisproj>/repo-patch/robots.txt .
cp <thisproj>/repo-patch/sitemap.xml .
cp <thisproj>/repo-patch/SEO-CHECKLIST.md .
cp <thisproj>/repo-patch/assets/og-image.png assets/
cp <thisproj>/repo-patch/directionA/legal.jsx directionA/
cp <thisproj>/repo-patch/directionA/shared.jsx directionA/

# Build prüfen
npm run build

# Smoke-Test
ls dist/
# erwartet u.a.: index.html, bundle.js, robots.txt, sitemap.xml, assets/og-image.png

git add -A
git commit -m "feat(seo): full SEO/GEO pass — JSON-LD, OG image, hash-router, legal pages"
git push origin main
```

## Was bewusst NICHT angefasst wurde

- `directionA/home.jsx`, `directionA/subpages.jsx`, `directionA/check.jsx`
  → Inhaltliche Copy-Anpassungen (H2 → Fragen, FAQ-Sektion im DOM) folgen separat.
- `directionB/*`, `design-canvas.jsx`, `tweaks-panel.jsx`
  → Bleiben für Design-Reviews aktiv. Production-Bundle nimmt sie nicht mehr mit (`build.mjs → ENTRY_FILES`).
- Cloudflare Pages-Einstellungen — manueller Schritt.

## Nach dem Deploy

1. https://innovation-republic.eu/robots.txt — erreichbar?
2. https://innovation-republic.eu/sitemap.xml — erreichbar?
3. https://validator.schema.org/ — Landing-URL einwerfen, alle Schemas grün?
4. https://search.google.com/test/rich-results — Rich-Results-Test bestehen?
5. Cloudflare Dashboard → Web Analytics aktivieren, Beacon-Snippet ans Ende von `<body>` (Slot in `build.mjs → generateIndexHtml` markiert).

Status der einzelnen Items: siehe `SEO-CHECKLIST.md`.
