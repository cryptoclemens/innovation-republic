# Mobile-Pass v3 — Patch-Notes

Stand: 2026-05-03 · Folge-Patch nach FAQ-Sektion-Pass.

## Was drin ist

### Neu
- **`directionA/style.responsive.css`** — komplette Mobile-/Tablet-Layer.
  - Page-Shell `width: 1440px` → `max-width: 1440px; width: 100%`
  - Fluid Padding via `clamp()` für alle Sektionen
  - Fluid Type für H1/H2/Hero/Stat-Numbers
  - Breakpoints: 960px (Tablet) und 640px (Phone)
  - Hamburger-Toggle ab < 880px
  - Auto-fit Grids für Process / Tools / Personas / Tiers / People / Footer
  - Touch-Targets ≥ 44px, Form-Inputs `font-size: 16px` (verhindert iOS-Zoom)
  - Sticky-Pill und Check-Modal mobile-fit
  - `prefers-reduced-motion`-Respekt

### Geändert
- **`directionA/shared.jsx`** — `ANav` bekommt einen `<button class="dirA-nav-toggle">` (Hamburger).
  - State über `useState`, zugänglich via `aria-expanded`/`aria-controls`
  - Body-Scroll-Lock solange Menü offen
  - Schließt automatisch bei `hashchange`
  - Toggle ist auf Desktop per CSS versteckt (`.dirA-nav-toggle { display: none }`),
    erscheint ab `< 880px`

## Was Claude Code macht

````
1. Files überschreiben:
   ZIP=$(ls -t Upload/*.zip | head -n 1)
   rm -rf Upload/_patch && unzip -o "$ZIP" -d Upload/_patch
   cp Upload/_patch/repo-patch/directionA/style.responsive.css directionA/style.responsive.css
   cp Upload/_patch/repo-patch/directionA/shared.jsx           directionA/shared.jsx

2. style.responsive.css NACH style.css einbinden.
   In index.html (Dev-Entry) suchen:
     <link rel="stylesheet" href="directionA/style.css" />
   Direkt darunter ergänzen:
     <link rel="stylesheet" href="directionA/style.responsive.css" />

   In build.mjs prüfen, dass beide CSS-Files in dist/ kopiert werden
   (copyAssets oder STATIC_ASSETS-Liste). Reihenfolge im generierten
   <head>: style.css → style.responsive.css → check.css.

3. Build + Smoke-Test:
   npm run build
   npm run dev
   # Chrome DevTools Device Mode:
   #   - iPhone SE (375×667): Hero stacks, Hamburger sichtbar
   #   - iPad (768×1024): 2-Spalten-Grids
   #   - Desktop (1440+): unverändert
   # Hamburger antippen → Menü-Drawer aufklappen → Link tappen → schließt
   # Body scrollt nicht, solange Menü offen

4. Commit + Push:
   git add directionA/style.responsive.css directionA/shared.jsx index.html build.mjs
   git commit -m "feat(mobile): responsive layer + hamburger nav"
   git push origin main
````

## Was bewusst NICHT in diesem Patch

- Keine Anpassung an `style.css` selbst — die Layer überschreibt nur dort, wo nötig.
  Damit bleibt der Desktop-Stand pixelgenau, falls wir die Layer kurzfristig
  rausnehmen müssen.
- Kein Refactor der Inline-Styles aus `home.jsx`/`subpages.jsx` zu CSS-Klassen.
  Inline-Styles sind in clamp/Grid-Auto-fit nicht mobile-blockierend.
- Kein neues Asset (Logo, OG-Subpages) — separater Pass.

## Bekannte Restpunkte für Folge-Pässe

- **Subpage-spezifische OG-Images** (eigener Patch)
- **Team-Sektion reaktivieren** sobald Personen public sind
- **EN-Toggle** Entscheidung treffen (implementieren oder entfernen)
- **Subpage-spezifische FAQPage-JSON-LD** sobald File-basiertes Routing kommt
- **Cloudflare Web Analytics Beacon** einsetzen (Snippet-Übergabe nötig)
