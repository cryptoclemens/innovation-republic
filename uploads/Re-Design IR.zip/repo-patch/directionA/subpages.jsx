/* Direction A — Subpages
 * SEO-Pass v2 (2026-05): + AFAQBlock pro Subpage (Plattform / KMU / Anbieter / Förderung / Über uns)
 * H2 als Frage (Inverted Pyramid). Microdata FAQPage/Question/Answer.
 * Hash-Routing-Fixes (#/-Targets statt nackter #).
 */

const APageHead = ({ crumb, title, lede }) => (
  <header className="dirA-pagehead">
    <div>
      <div className="dirA-breadcrumb">
        <a href="#/">Innovation Republic</a> / {crumb}
      </div>
      <h1>{title}</h1>
    </div>
    <p>{lede}</p>
  </header>
);

/* === Wiederverwendbarer FAQ-Block für Subpages =====================
 * Sichtbar im DOM. Microdata für Crawler.
 * Nimmt items[] mit {q, a} und einen optionalen secno (z.B. "Häufige Fragen · 04").
 * ================================================================ */
const AFAQBlock = ({ secno = "Häufige Fragen", title = "Was Sie wahrscheinlich noch fragen.", lede, items }) => (
  <section
    className="dirA-section"
    aria-labelledby={`faq-${secno.replace(/\s+/g, '-').toLowerCase()}`}
    itemScope
    itemType="https://schema.org/FAQPage"
  >
    <div className="dirA-sec-head">
      <div>
        <div className="dirA-secno">{secno}</div>
        <h2 id={`faq-${secno.replace(/\s+/g, '-').toLowerCase()}`}>{title}</h2>
      </div>
      {lede && <p className="body-lg" style={{ alignSelf: "end" }}>{lede}</p>}
    </div>
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
        gap: 24,
        marginTop: 8,
      }}
    >
      {items.map((it, i) => (
        <article
          key={it.q}
          itemScope
          itemProp="mainEntity"
          itemType="https://schema.org/Question"
          style={{
            background: "var(--bg-elev)",
            border: "1px solid var(--line)",
            borderRadius: 16,
            padding: "28px 28px 26px",
            display: "flex",
            flexDirection: "column",
            gap: 12,
          }}
        >
          <div
            className="mono"
            style={{
              fontFamily: "var(--f-mono)",
              fontSize: 11,
              color: "var(--ink-3)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
            }}
          >
            Frage 0{i + 1}
          </div>
          <h3
            itemProp="name"
            className="h4"
            style={{ margin: 0, fontSize: 20, lineHeight: 1.25, color: "var(--ink)" }}
          >
            {it.q}
          </h3>
          <div itemScope itemProp="acceptedAnswer" itemType="https://schema.org/Answer">
            <p
              itemProp="text"
              className="body"
              style={{ margin: 0, color: "var(--ink-1)", lineHeight: 1.6 }}
            >
              {it.a}
            </p>
          </div>
        </article>
      ))}
    </div>
  </section>
);

/* === PLATTFORM === */
const ADirectionAPlatform = () => (
  <div className="dirA dirA-page" data-screen-label="A-02 Plattform">
    <ANav active="platform" />
    <APageHead
      crumb="Plattform"
      title="Wie kuratiert Innovation Republic den Innovations-Prozess?"
      lede="Innovation Republic ist Ihr gemeinnütziger Kurator: Wir orchestrieren den End-to-End-Innovations-Prozess in vier Phasen und integrieren in jeder das beste verfügbare Tool. Für Bedarfsträger kostenfrei. Optional buchbare Berater pro Phase."
    />
    <section className="dirA-section">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Der Prozess</div>
          <h2>Welche vier Phasen durchläuft jedes Vorhaben?</h2>
        </div>
        <p className="body-lg" style={{ alignSelf: "end" }}>
          Jede Phase wird durch ein kuratiertes, best-in-class Tool unterstützt. Für Bedarfsträger kostenfrei. Optional buchbare Berater-Hilfe pro Phase über Roland.
        </p>
      </div>
      <div className="dirA-process">
        {APhases.map(p => (
          <div key={p.num} className="dirA-step">
            <div className="num">PHASE {p.num}</div>
            <h4>{p.name}</h4>
            <p>{p.desc}</p>
            <div className={`tool ${p.status === "soon" ? "soon" : ""}`}>
              <span className="pip"></span>
              {p.status === "soon" ? `${p.tool} · soon` : `${p.tool} · live`}
            </div>
          </div>
        ))}
      </div>
    </section>
    <section className="dirA-section alt">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Toolstack</div>
          <h2>Welche Tools sind heute live?</h2>
        </div>
        <p className="body-lg" style={{ alignSelf: "end" }}>
          Statt Eigenbau setzt Innovation Republic auf bewährte Spezial-Tools. Die meisten Slots sind aktuell offen — sprechen Sie uns an, wenn Sie ein Tool beisteuern möchten.
        </p>
      </div>
      <div className="dirA-tools-grid">
        {TOOLS.map(t => (
          <div key={t.code} className={`dirA-tool-card ${t.status}`}>
            <span className={`badge ${t.status}`}>{t.status === "live" ? "LIVE" : "COMING SOON"}</span>
            <div className="icon">{t.code}</div>
            <div>
              <div className="name">{t.name}</div>
              <div className="placeholder">{t.placeholder}</div>
            </div>
            <div className="desc">{t.desc}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 32, padding: 24, border: "1px dashed var(--line-2)", borderRadius: 16, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div className="mono" style={{ color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Tool-Slot offen</div>
          <div className="h4">Sie haben ein Best-in-Class-Tool? Werden Sie kuratierter IR-Tool-Partner.</div>
        </div>
        <a href="mailto:hello@innovationrepublic.de?subject=Tool-Vorschlag" className="dirA-btn dirA-btn-primary">Tool vorschlagen <span className="arr">→</span></a>
      </div>
    </section>
    <AFAQBlock
      secno="Häufige Fragen · Plattform"
      title="Was Sie zur Plattform wahrscheinlich noch fragen."
      items={[
        {
          q: "Was unterscheidet Innovation Republic von einem Marktplatz?",
          a: "Marktplätze listen Anbieter und überlassen Auswahl, Briefing und Steuerung dem Auftraggeber. Innovation Republic kuratiert den gesamten Prozess: Bedarf schärfen, Anbieter matchen, Sprint strukturieren, Ergebnis dokumentieren. Wir vermitteln nicht nur, wir begleiten.",
        },
        {
          q: "Welche Tools sind heute schon live, welche kommen?",
          a: "Live ist heute der Innovations-Check (Reife-Selbstdiagnose) sowie Robert (Bedarfsklärung in der Pilotphase). Konrad (Anbieter-Matching), James (Sprint-Begleitung) und der Fördergeld-Check sind in Vorbereitung. Den aktuellen Stand sehen Sie jederzeit am Status-Pip („live"/„soon") an jedem Tool.",
        },
        {
          q: "Können wir eigene Tools an die Plattform anbinden?",
          a: "Ja — Innovation Republic ist bewusst offen. Wenn Sie ein bewährtes Spezial-Tool für eine Phase haben (z. B. ein Anbieter-Datenbank, ein Sprint-Management-Tool, ein Förderfilter), können Sie sich als Tool-Partner bewerben. Wir kuratieren mit klaren Qualitätskriterien.",
        },
        {
          q: "Brauchen wir die Plattform überhaupt — wir haben doch eigene Innovationsprozesse?",
          a: "Wenn Ihr eigener Prozess funktioniert, super — dann nutzen Sie uns punktuell, etwa für Anbieter-Matching oder Förderrecherche. Innovation Republic ist additiv, nicht ersetzend. Die meisten KMU haben keinen eigenen Innovationsprozess — für die ist die Plattform der Einstieg.",
        },
      ]}
    />
    <ACTAStrip />
    <AFooter />
  </div>
);

/* === FÜR BEDARFSTRÄGER === */
const ADirectionAKMU = () => (
  <div className="dirA dirA-page" data-screen-label="A-03 Bedarfsträger">
    <ANav active="kmu" />
    <APageHead
      crumb="Für Bedarfsträger"
      title="Sie wissen, dass Sie innovieren müssen — aber nicht wie?"
      lede="Genau hier setzen wir an. Innovation Republic kuratiert mit Ihnen den Prozess: vom unscharfen Bedarf über kuratierte Anbieter bis zur strukturierten Sprint-Zusammenarbeit. Kostenfrei, gemeinnützig, vergabekonform."
    />
    <div className="dirA-stats" style={{ background: "var(--bg-elev)" }}>
      <div className="dirA-stat"><div className="num">0 €</div><div className="label">Plattform-Kosten</div></div>
      <div className="dirA-stat"><div className="num">14<span className="unit">Tage</span></div><div className="label">Bis Lösungsvorschläge</div></div>
      <div className="dirA-stat"><div className="num">100<span className="unit">WT</span></div><div className="label">Bis Proof of Concept</div></div>
      <div className="dirA-stat"><div className="num">100%</div><div className="label">Vergabekonform</div></div>
    </div>
    <section className="dirA-section">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Hürden, die wir lösen</div>
          <h2>Was bremst KMU heute beim Innovieren?</h2>
        </div>
      </div>
      <div className="dirA-personas">
        {[
          { t: "Kein Zugang zu Startups", d: "Keine Zeit fürs Scouting, kein Netzwerk in der Szene. Konrad kuratiert passende Anbieter automatisch." },
          { t: "Lange Beschaffungswege", d: "Anstatt monatelanger Vergabeprozesse: 14-Tage-Wettbewerb mit standardisierten, einkaufskonformen Verträgen." },
          { t: "Risiko-Aversion", d: "Neutrales Risiko-Assessment vor dem PoC. Klare Abbruchkriterien. Dokumentierter Erkenntnisgewinn." },
        ].map(x => (
          <div key={x.t} className="dirA-persona">
            <span className="tag"><span className="sq" style={{ background: "var(--ink)" }}></span>Hürde</span>
            <h3>{x.t}</h3>
            <p>{x.d}</p>
          </div>
        ))}
      </div>
    </section>
    <section className="dirA-section alt">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">So starten Sie</div>
          <h2>Wie kommen Sie in 10 Minuten zu einem klaren Bedarf?</h2>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 32 }}>
        <div style={{ background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 16, padding: 32 }}>
          <div className="mono" style={{ color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 16 }}>Schritt 1 · Robert</div>
          <h3 className="h3">Bedarf strukturieren</h3>
          <p className="body" style={{ marginTop: 12 }}>KI-gestützte Eingabe: Sie beschreiben das Problem in eigenen Worten. Robert formt daraus eine ausschreibungsfähige Anforderung.</p>
          <div style={{ marginTop: 24, background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 10, padding: 16, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-2)", lineHeight: 1.6 }}>
            <span style={{ color: "var(--ink-3)" }}>{"// Beispiel"}</span><br />
            <span style={{ color: "var(--accent-red)" }}>BEDARF:</span> Predictive Maintenance für CNC-Park<br />
            <span style={{ color: "var(--accent-red)" }}>BUDGET:</span> 25k–50k €<br />
            <span style={{ color: "var(--accent-red)" }}>RAHMEN:</span> 100 WT, vor Ort + remote<br />
            <span style={{ color: "var(--accent-gold)" }}>STATUS:</span> Bereit zur Ausschreibung ✓
          </div>
        </div>
        <div style={{ background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 16, padding: 32 }}>
          <div className="mono" style={{ color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 16 }}>Schritt 2 · SpinIn</div>
          <h3 className="h3">Anbieter wählen</h3>
          <p className="body" style={{ marginTop: 12 }}>14-Tage-Ausschreibung über SpinIn. Sie erhalten kuratierte Vorschläge, vergleichen sie strukturiert, wählen den Partner.</p>
          <div style={{ marginTop: 24, display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              { n: "AnbieterA GmbH", m: "94% Match", l: "München" },
              { n: "PredictTech UG", m: "89% Match", l: "Berlin" },
              { n: "MaintainAI", m: "82% Match", l: "Stuttgart" },
            ].map(a => (
              <div key={a.n} style={{ display: "flex", justifyContent: "space-between", padding: "12px 16px", background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 10, alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{a.n}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>{a.l}</div>
                </div>
                <div className="mono" style={{ fontSize: 11, color: "var(--accent-gold)", fontWeight: 600 }}>{a.m}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
    <AFAQBlock
      secno="Häufige Fragen · KMU"
      title="Was KMU vor dem Start meistens fragen."
      items={[
        {
          q: "Was kostet uns die Nutzung von Innovation Republic?",
          a: "Die Bedarfsklärung über Robert und das Anbieter-Matching über Konrad sind für KMU kostenfrei. Nur der konkrete Sprint mit dem ausgewählten Anbieter wird abgerechnet — direkt zwischen Ihnen und dem Anbieter, wo möglich mit Förderung. Innovation Republic nimmt keine Provision.",
        },
        {
          q: "Wie lange dauert es, bis wir Lösungsvorschläge bekommen?",
          a: "Vom strukturierten Bedarf bis zu kuratierten Anbieter-Vorschlägen rechnen wir 14 Tage. Der eigentliche Sprint startet danach in der Regel innerhalb von zwei bis vier Wochen — je nach Verfügbarkeit der gewählten Partner und Komplexität des Vorhabens.",
        },
        {
          q: "Ist das vergabekonform für öffentliche Auftraggeber?",
          a: "Ja. Wir arbeiten mit standardisierten, einkaufskonformen Vertragswerken und transparenter Anbieterauswahl. Für unterschwellige Vergaben funktioniert der Prozess direkt; bei größeren Volumina liefern wir die Marktrecherche und das strukturierte Vergleichsraster, das Ihre Vergabestelle ohnehin braucht.",
        },
        {
          q: "Was passiert, wenn der Sprint scheitert?",
          a: "Jeder Sprint hat von Anfang an dokumentierte Abbruchkriterien. Wenn das Vorhaben nicht trägt, wird der Sprint kontrolliert beendet — und Sie haben einen dokumentierten Erkenntnisgewinn statt eines diffusen Misserfolgs. Das ist ausdrücklich Teil des Modells, nicht ein Ausnahmefall.",
        },
      ]}
    />
    <ACTAStrip />
    <AFooter />
  </div>
);

/* === FÜR ANBIETER === */
const ADirectionAAnbieter = () => (
  <div className="dirA dirA-page" data-screen-label="A-04 Anbieter">
    <ANav active="anbieter" />
    <APageHead
      crumb="Für Anbieter"
      title="Wie kommen Sie an reale Aufträge aus dem Mittelstand?"
      lede="Innovation Republic kuratiert reale Bedarfe aus dem Mittelstand und der öffentlichen Hand — strukturiert, vergabekonform, sprint-tauglich. Sie bekommen Zugang zu Auftraggebern, die wissen, was sie brauchen."
    />
    <section className="dirA-section">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Vorteile</div>
          <h2>Was haben Anbieter konkret davon?</h2>
        </div>
      </div>
      <div className="dirA-personas">
        {[
          { t: "Kürzere Vertriebszyklen", d: "Statt 12–18 Monate Cold-Outreach: kuratierte Bedarfe, die zu Ihrer Lösung passen, mit kaufbereiten Auftraggebern." },
          { t: "Reale Referenzen", d: "Jeder Auftrag ist eine dokumentierte Referenz aus dem deutschen Mittelstand — relevant für Investoren und nächste Kunden." },
          { t: "Vergabekonforme Verträge", d: "Standardisierte Vertragswerke, kompatibel mit öffentlichem Einkauf. Kein eigenes Compliance-Team nötig." },
        ].map(x => (
          <div key={x.t} className="dirA-persona">
            <span className="tag"><span className="sq" style={{ background: "var(--accent-red)" }}></span>Vorteil</span>
            <h3>{x.t}</h3>
            <p>{x.d}</p>
          </div>
        ))}
      </div>
    </section>
    <section className="dirA-section alt">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Onboarding</div>
          <h2>Wie werden Sie Anbieter — Schritt für Schritt?</h2>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
        {[
          { n: "01", t: "Profil anlegen", d: "Lösung, Branchen, Referenzen." },
          { n: "02", t: "Verifizierung", d: "Identitäts- und Compliance-Check." },
          { n: "03", t: "Matching aktivieren", d: "Konrad findet passende Bedarfe." },
          { n: "04", t: "Vorschläge einreichen", d: "Auf laufende Ausschreibungen." },
        ].map(s => (
          <div key={s.n} style={{ background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 14, padding: 24 }}>
            <div className="mono" style={{ color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>{s.n}</div>
            <div className="h4" style={{ marginBottom: 8 }}>{s.t}</div>
            <div className="body-sm">{s.d}</div>
          </div>
        ))}
      </div>
    </section>
    <AFAQBlock
      secno="Häufige Fragen · Anbieter"
      title="Was Anbieter vor dem Onboarding fragen."
      items={[
        {
          q: "Welche Anbieter passen zu Innovation Republic?",
          a: "Wir kuratieren Lösungsanbieter aus dem Spektrum Startups, Scale-ups, Spezialagenturen, Forschungs-Spin-offs sowie etablierte Mittelständler mit klar abgrenzbaren Innovations-Angeboten. Entscheidend ist nicht die Unternehmensform, sondern die Sprint-Tauglichkeit: liefern Sie ein klar umrissenes Ergebnis in 4–12 Wochen?",
        },
        {
          q: "Was kostet die Aufnahme als Anbieter?",
          a: "Die Aufnahme und das Matching sind kostenfrei. Innovation Republic finanziert sich über Förderpartnerschaften, nicht über Anbieter-Provisionen. Das ist Teil des gemeinnützigen Modells und ein bewusster Unterschied zu kommerziellen Plattformen.",
        },
        {
          q: "Wie funktioniert der Auswahlprozess für eine konkrete Ausschreibung?",
          a: "Konrad matcht passende Anbieter automatisiert anhand strukturierter Kriterien. Sie erhalten eine Einladung zur Bedarfssituation, prüfen Fit, und reichen ein strukturiertes Sprint-Angebot ein. Der Auftraggeber entscheidet anhand eines Vergleichsrasters — kein Pitching-Theater.",
        },
        {
          q: "Wie sehen die Standardverträge aus?",
          a: "Die Sprint-Verträge sind als Werkvertrag mit fixem Scope, fixem Zeitfenster (typisch 4–12 Wochen) und definiertem Liefergegenstand strukturiert. Kompatibel mit öffentlichem Einkauf, geprüft auf KMU-Tauglichkeit. Anpassungen pro Vorhaben sind möglich, Kernrahmen bleibt.",
        },
      ]}
    />
    <ACTAStrip />
    <AFooter />
  </div>
);

/* === SPENDEN / FÖRDERUNG === */
const ADirectionASpenden = () => (
  <div className="dirA dirA-page" data-screen-label="A-05 Förderung">
    <ANav active="spenden" />
    <APageHead
      crumb="Förderung"
      title="Warum lohnt sich Förderung von Innovation Republic?"
      lede="Innovation Republic ist eine gemeinnützige Initiative von Unternehmern (in Gründung). Wir finanzieren uns über Spenden und Förderpartnerschaften. Jeder Euro fließt in einen kuratierten Prozess, der reale Innovation in der Breite freisetzt — transparent ausgewiesen."
    />
    <section className="dirA-section">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Mitwirken</div>
          <h2>Welche drei Wege gibt es zu fördern?</h2>
        </div>
      </div>
      <div className="dirA-tiers">
        <div className="dirA-tier">
          <div className="label">Start-Funding</div>
          <h3>Plattform-Aufbau</h3>
          <div className="price">ab 25.000 <span className="unit">€</span></div>
          <p className="body-sm">Grundfinanzierung der Plattform-Infrastruktur und Kern-Apps.</p>
          <ul>
            <li>Nennung als Founding Partner</li>
            <li>Quartalsweises Impact-Reporting</li>
            <li>Zugang zu Pilot-Daten</li>
          </ul>
          <a href="mailto:hello@innovationrepublic.de?subject=Start-Funding" className="dirA-btn dirA-btn-ghost cta">Sprechen <span className="arr">→</span></a>
        </div>
        <div className="dirA-tier featured">
          <div className="label" style={{ color: "var(--accent-gold)" }}>Empfohlen</div>
          <h3>Regional-Partnerschaft</h3>
          <div className="price">ab 100.000 <span className="unit">€ / Jahr</span></div>
          <p>Etablierung eines regionalen Knotenpunkts inkl. Kommunikations- und Netzwerkbudget.</p>
          <ul>
            <li>Eigene Region, eigenes Branding</li>
            <li>Lokale Makeathons & Innovation-Labs</li>
            <li>Politische Schirmherrschaft</li>
            <li>Direkte Auftragsvermittlung</li>
          </ul>
          <a href="mailto:hello@innovationrepublic.de?subject=Regional-Partnerschaft" className="dirA-btn dirA-btn-primary cta" style={{ background: "var(--accent-gold)", color: "var(--ink)" }}>Partner werden <span className="arr">→</span></a>
        </div>
        <div className="dirA-tier">
          <div className="label">Projektbezogen</div>
          <h3>Pilotprogramm fördern</h3>
          <div className="price">ab 10.000 <span className="unit">€</span></div>
          <p className="body-sm">Z.B. „1-Day Innovation Sprint" oder „KMU-Innovationstestfeld Süd".</p>
          <ul>
            <li>Direkte Wirkungsmessung</li>
            <li>Public Branding der Maßnahme</li>
            <li>Steuerlich abzugsfähig</li>
          </ul>
          <a href="mailto:hello@innovationrepublic.de?subject=Pilotprogramm" className="dirA-btn dirA-btn-ghost cta">Spenden <span className="arr">→</span></a>
        </div>
      </div>
    </section>
    <section className="dirA-section alt">
      <div className="dirA-sec-head">
        <div>
          <div className="dirA-secno">Transparenz</div>
          <h2>Wohin fließen die Mittel?</h2>
        </div>
        <p className="body-lg" style={{ alignSelf: "end" }}>
          Alle Mittel fließen ausschließlich in den gemeinnützigen Zweck der Initiative — Förderung von Innovation im Mittelstand. Die Anerkennung als gemeinnützige Trägerstruktur (e.V. oder gGmbH) wird vorbereitet. Projektergebnisse und Impact-Kennzahlen werden öffentlich ausgewiesen.
        </p>
      </div>
      <div className="dirA-stats" style={{ background: "var(--bg)" }}>
        <div className="dirA-stat"><div className="num">87%</div><div className="label">Projektkosten</div></div>
        <div className="dirA-stat"><div className="num">9%</div><div className="label">Plattform-Betrieb</div></div>
        <div className="dirA-stat"><div className="num">4%</div><div className="label">Verwaltung</div></div>
        <div className="dirA-stat"><div className="num">100%</div><div className="label">Öffentlich auditiert</div></div>
      </div>
    </section>
    <AFAQBlock
      secno="Häufige Fragen · Förderung"
      title="Was Förderer und Spender vor dem Engagement fragen."
      items={[
        {
          q: "Ist Innovation Republic bereits als gemeinnützig anerkannt?",
          a: "Innovation Republic ist eine Initiative in Gründung. Bis zur Eintragung des Innovation Republic e.V. übernimmt die vencly GmbH (München, HRB 290524) die operative Trägerschaft. Spenden über die Trägerstruktur sind möglich; die formale Gemeinnützigkeitsanerkennung wird mit der Vereinsgründung beantragt.",
        },
        {
          q: "Sind Spenden steuerlich abzugsfähig?",
          a: "Bis zur formalen Anerkennung der Gemeinnützigkeit sind Förderbeiträge als Sponsoring oder Projektpartnerschaft steuerlich absetzbar. Nach Anerkennung des e.V. werden Spendenquittungen ausgestellt. Den genauen Status zum Zeitpunkt Ihres Engagements klären wir transparent vor jeder Zuwendung.",
        },
        {
          q: "Wie wird die Mittelverwendung dokumentiert?",
          a: "Förderer erhalten ein quartalsweises Impact-Reporting mit Mittelverwendung, Projektkennzahlen und kuratierten Sprint-Ergebnissen. Die Verteilung ist öffentlich ausgewiesen: ca. 87 % Projektkosten, 9 % Plattform-Betrieb, 4 % Verwaltung. Ziel ist eine externe Auditierbarkeit ab Jahr eins.",
        },
        {
          q: "Können wir eine eigene Region oder ein eigenes Programm fördern?",
          a: "Ja. Regional-Partnerschaften ab 100.000 € / Jahr etablieren einen eigenen Knotenpunkt mit eigenem Branding, lokalen Makeathons und politischer Schirmherrschaft. Projektbezogene Förderungen ab 10.000 € unterstützen einzelne Pilotprogramme — etwa „KMU-Innovationstestfeld Süd".",
        },
      ]}
    />
    <AFooter />
  </div>
);

/* === ÜBER UNS / KONTAKT === */
const ADirectionAUeber = () => (
  <div className="dirA dirA-page" data-screen-label="A-06 Über uns">
    <ANav active="ueber" />
    <APageHead
      crumb="Über uns"
      title="Wer steht hinter Innovation Republic?"
      lede="Innovation Republic ist eine gemeinnützige Initiative von Unternehmern aus dem deutschen Mittelstand (in Gründung). Pilotregion: München & Oberbayern. Die Trägerstruktur (e.V. oder gGmbH) wird derzeit aufgesetzt; weitere Knotenpunkte folgen bundesweit."
    />
    {/* TEAM-SEKTION — Platzhalter im Code, aktuell ausgeblendet.
        Solange nur Clemens an Bord ist, wirkt eine Team-Galerie + "wir" peinlich.
        Reaktivieren, sobald min. 2–3 Personen / Beirat öffentlich kommunizierbar sind. */}
    {false && (
      <section className="dirA-section">
        <div className="dirA-sec-head">
          <div>
            <div className="dirA-secno">Vorstand & Team</div>
            <h2>Menschen hinter dem Projekt.</h2>
          </div>
        </div>
        <div className="dirA-people">
          {[
            { i: "CP", n: "Clemens Pompeÿ", r: "Vorstand", b: "Gründer Innovation Republic. Vorher Strategy & Innovation in Mittelstand und öffentlicher Hand." },
            { i: "MD", n: "Vorstand 2", r: "Stellv. Vorstand", b: "Platzhalter — Bio folgt." },
            { i: "BS", n: "Beirat", r: "Wissenschaftlicher Beirat", b: "TUM, UnternehmerTUM Netzwerk." },
            { i: "PR", n: "Politik", r: "Schirmherrschaft", b: "MdL Kerstin Schreyer, Stefan Ebner, Stephanie Schuhknecht u.a." },
          ].map(p => (
            <div key={p.i} className="dirA-person">
              <div className="avatar">{p.i}</div>
              <div className="name">{p.n}</div>
              <div className="role">{p.r}</div>
              <div className="bio">{p.b}</div>
            </div>
          ))}
        </div>
      </section>
    )}
    <AFAQBlock
      secno="Häufige Fragen · Über uns"
      title="Was Sie zur Initiative wissen wollen."
      items={[
        {
          q: "Wer trägt Innovation Republic operativ heute?",
          a: "Bis zur Gründung eines eigenen Innovation Republic e.V. übernimmt die vencly GmbH (München, HRB 290524) die operative Trägerschaft inklusive Plattform-Betrieb, Vertragsabwicklung und Datenschutz-Verantwortung. Verantwortlich: Clemens Pompeÿ.",
        },
        {
          q: "Wann wird der Verein gegründet?",
          a: "Die Gründung des Innovation Republic e.V. ist für 2026 geplant, sobald Vorstand und Beirat formal besetzt sind. Bis dahin läuft die Initiative unter der vencly-Trägerschaft mit transparenter Mittelverwendung. Den aktuellen Status kommunizieren wir auf der Über-uns-Seite.",
        },
        {
          q: "Wo ist Innovation Republic regional aktiv?",
          a: "Pilotregion ist München & Oberbayern, mit Anbindung an das UnternehmerTUM- und TUM-Netzwerk. Bundesweit ausrollen wollen wir über Regional-Partnerschaften — jede Region bekommt ihren eigenen Knotenpunkt mit lokalem Branding und politischer Schirmherrschaft.",
        },
        {
          q: "Wie kann man mitmachen, ohne KMU oder Anbieter zu sein?",
          a: "Drei Wege: als Förderer (Spenden, Regional-Partnerschaft, Pilotprogramm), als Tool-Partner (eigenes Best-in-Class-Tool für eine Phase beisteuern), oder als Botschafter im eigenen Netzwerk. Schreiben Sie uns einfach unter hello@innovationrepublic.de.",
        },
      ]}
    />
    <section className="dirA-section alt">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 64 }}>
        <div>
          <div className="dirA-secno">Kontakt</div>
          <h2 className="h2" style={{ marginTop: 16 }}>Sprechen Sie mit uns.</h2>
          <p className="body-lg" style={{ marginTop: 20, maxWidth: 460 }}>
            Ob Bedarf, Lösung, Förderung oder einfach Interesse — wir freuen uns über Ihre Nachricht.
          </p>
          <div style={{ marginTop: 32, display: "flex", flexDirection: "column", gap: 14, fontFamily: "var(--f-mono)", fontSize: 13 }}>
            <div><span style={{ color: "var(--ink-3)" }}>E-MAIL </span>hello@innovationrepublic.de</div>
            <div><span style={{ color: "var(--ink-3)" }}>TEL    </span>+49.162.6677606</div>
            <div><span style={{ color: "var(--ink-3)" }}>WEB    </span>www.innovation-republic.eu</div>
            <div><span style={{ color: "var(--ink-3)" }}>DEMO   </span>demo.innovation-republic.eu</div>
          </div>
        </div>
        <form className="dirA-form" onSubmit={(e) => { e.preventDefault(); window.location.href = "mailto:hello@innovationrepublic.de"; }}>
          <div className="dirA-field">
            <label>Name</label>
            <input placeholder="Ihr Name" />
          </div>
          <div className="dirA-field">
            <label>Organisation</label>
            <input placeholder="Firma / Verband / Behörde" />
          </div>
          <div className="dirA-field">
            <label>E-Mail</label>
            <input placeholder="name@firma.de" />
          </div>
          <div className="dirA-field">
            <label>Ich bin</label>
            <select>
              <option>Bedarfsträger (KMU / öffentliche Hand)</option>
              <option>Lösungsanbieter (Startup / Scale-up / Agentur)</option>
              <option>Förderer / Industrie-Partner</option>
              <option>Politik / Verwaltung</option>
              <option>Sonstiges</option>
            </select>
          </div>
          <div className="dirA-field">
            <label>Nachricht</label>
            <textarea placeholder="Worum geht es?" />
          </div>
          <button type="submit" className="dirA-btn dirA-btn-primary" style={{ alignSelf: "flex-start", border: "none", font: "inherit" }}>Nachricht senden <span className="arr">→</span></button>
        </form>
      </div>
    </section>
    <AFooter />
  </div>
);

Object.assign(window, {
  AFAQBlock,
  ADirectionAPlatform, ADirectionAKMU, ADirectionAAnbieter,
  ADirectionASpenden, ADirectionAUeber
});
